package enums_and_annotations.cardgame.interfaces;


import enums_and_annotations.cardgame.models.Card;

public interface Deck {

    Card receiveCardFromDeck(String cardName);

}
