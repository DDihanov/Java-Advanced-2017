package enums_and_annotations.cardgame.interfaces;

public interface Player {

    String getName();
}
