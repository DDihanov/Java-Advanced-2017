package enums_and_annotations.cardgame.interfaces;


import enums_and_annotations.cardgame.models.Card;

public interface CardPlayer extends Player {

    void addCard(Card card);

    Card getHighestCard();
}
