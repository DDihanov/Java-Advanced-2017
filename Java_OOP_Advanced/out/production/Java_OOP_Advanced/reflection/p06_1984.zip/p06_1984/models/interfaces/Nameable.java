package reflection.p06_1984.models.interfaces;

public interface Nameable {
    String getName();
}
