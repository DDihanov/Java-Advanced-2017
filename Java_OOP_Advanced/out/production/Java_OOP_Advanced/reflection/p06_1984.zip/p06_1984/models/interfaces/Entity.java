package reflection.p06_1984.models.interfaces;

public interface Entity extends Observable,Nameable, Identifiable{

}
