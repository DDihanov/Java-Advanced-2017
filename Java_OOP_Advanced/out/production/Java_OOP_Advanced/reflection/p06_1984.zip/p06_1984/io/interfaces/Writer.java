package reflection.p06_1984.io.interfaces;

public interface Writer {

    void writeLine(String output);

    void write(String output);
}
