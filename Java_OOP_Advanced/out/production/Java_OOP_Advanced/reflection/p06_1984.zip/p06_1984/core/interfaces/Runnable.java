package reflection.p06_1984.core.interfaces;

import java.io.IOException;

public interface Runnable {

    void run() throws IOException, ReflectiveOperationException;
}
