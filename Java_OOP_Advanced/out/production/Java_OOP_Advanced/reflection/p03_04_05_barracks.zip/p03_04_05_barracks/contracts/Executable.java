package reflection.p03_04_05_barracks.contracts;

public interface Executable {

	String execute() throws ReflectiveOperationException;

}
