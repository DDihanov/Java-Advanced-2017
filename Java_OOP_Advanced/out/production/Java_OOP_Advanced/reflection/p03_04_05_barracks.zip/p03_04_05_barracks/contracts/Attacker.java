package reflection.p03_04_05_barracks.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
