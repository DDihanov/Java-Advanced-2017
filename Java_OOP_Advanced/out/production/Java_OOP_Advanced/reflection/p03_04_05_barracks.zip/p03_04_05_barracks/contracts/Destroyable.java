package reflection.p03_04_05_barracks.contracts;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
