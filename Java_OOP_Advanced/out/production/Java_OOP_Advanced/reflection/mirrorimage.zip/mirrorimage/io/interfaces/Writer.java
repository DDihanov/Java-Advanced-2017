package reflection.mirrorimage.io.interfaces;

public interface Writer {

    void write(String output);

    void writeLine(String output);
}
