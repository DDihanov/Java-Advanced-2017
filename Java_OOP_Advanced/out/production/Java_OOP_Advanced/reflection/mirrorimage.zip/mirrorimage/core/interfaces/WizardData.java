package reflection.mirrorimage.core.interfaces;

import reflection.mirrorimage.models.interfaces.Wizard;

public interface WizardData {

    void addWizard(Wizard wizard);

    Wizard getWizard(int id);

    void addSpellResult(String spellResult);

    String getSpellResults();
}
