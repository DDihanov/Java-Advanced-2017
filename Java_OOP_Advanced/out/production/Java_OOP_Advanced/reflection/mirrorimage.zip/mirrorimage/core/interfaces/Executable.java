package reflection.mirrorimage.core.interfaces;

public interface Executable {

    void execute(String[] args);
}
