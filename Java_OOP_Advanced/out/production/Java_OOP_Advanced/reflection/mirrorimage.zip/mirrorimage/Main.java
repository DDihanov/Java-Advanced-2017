package reflection.mirrorimage;

import reflection.mirrorimage.core.Command;
import reflection.mirrorimage.core.Engine;
import reflection.mirrorimage.core.interfaces.Executable;
import reflection.mirrorimage.io.ConsoleReader;
import reflection.mirrorimage.io.ConsoleWriter;
import reflection.mirrorimage.io.interfaces.Reader;
import reflection.mirrorimage.io.interfaces.Writer;
import reflection.mirrorimage.core.interfaces.Runnable;

import java.io.IOException;

public class Main {

    public static void main(String[] args) {

        Reader reader = new ConsoleReader();
        Writer writer = new ConsoleWriter();
        Executable executable = new Command();

        Runnable runnable = new Engine(reader, writer,executable);
        try {
            runnable.run();
        } catch (IOException ex) {
            System.out.println((ex.getMessage()));
        }
    }
}
