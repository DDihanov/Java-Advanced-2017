package reflection.mirrorimage.models.interfaces;

import reflection.mirrorimage.enums.SpellType;

public interface Spell {

    void   cast();

    SpellType getSpellType();

    Wizard getWizard();
}
