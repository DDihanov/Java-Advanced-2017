package reflection.mirrorimage.models.interfaces;

public interface Listener {

    void update(Spell spell);
}
