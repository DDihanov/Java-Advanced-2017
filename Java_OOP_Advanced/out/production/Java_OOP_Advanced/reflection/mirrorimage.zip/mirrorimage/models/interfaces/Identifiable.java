package reflection.mirrorimage.models.interfaces;

public interface Identifiable {

    int getId();
}
