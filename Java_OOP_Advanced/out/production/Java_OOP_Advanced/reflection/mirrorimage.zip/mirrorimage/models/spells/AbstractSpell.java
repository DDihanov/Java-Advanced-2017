package reflection.mirrorimage.models.spells;

import reflection.mirrorimage.enums.SpellType;
import reflection.mirrorimage.models.interfaces.Spell;
import reflection.mirrorimage.models.interfaces.Wizard;

public abstract class AbstractSpell implements Spell {

    private SpellType spellType;
    private Wizard wizard;

    protected AbstractSpell(SpellType spellType, Wizard wizard) {
        this.spellType = spellType;
        this.wizard = wizard;
    }

    public Wizard getWizard() {
        return this.wizard;
    }

    @Override
    public SpellType getSpellType() {
        return this.spellType;
    }

    @Override
    public abstract void cast();

}
