package reflection.mirrorimage.models.interfaces;

public interface Namable {

    String getName();
}
