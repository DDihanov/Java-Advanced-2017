package reflection.mirrorimage.factories;

import reflection.mirrorimage.enums.SpellType;
import reflection.mirrorimage.models.interfaces.Spell;
import reflection.mirrorimage.models.interfaces.Wizard;
import reflection.mirrorimage.models.spells.Fireball;
import reflection.mirrorimage.models.spells.Reflection;

public class SpellFactory {

    public static Spell createSpell(SpellType spellType, Wizard wizard) {

        switch (spellType) {
            case REFLECTION:
                return new Reflection(spellType, wizard);
            case FIREBALL:
                return new Fireball(spellType, wizard);
            default:
                throw new IllegalArgumentException("No such spell");
        }
    }
}
