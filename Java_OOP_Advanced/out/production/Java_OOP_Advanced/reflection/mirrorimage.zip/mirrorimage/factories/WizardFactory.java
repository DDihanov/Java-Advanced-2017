package reflection.mirrorimage.factories;

import reflection.mirrorimage.models.WizardImpl;
import reflection.mirrorimage.models.interfaces.Wizard;

public class WizardFactory {

    private static int id = 0;

    public static Wizard createWizard(String name, int power) {
        return new WizardImpl(id++, name, power);
    }
}
