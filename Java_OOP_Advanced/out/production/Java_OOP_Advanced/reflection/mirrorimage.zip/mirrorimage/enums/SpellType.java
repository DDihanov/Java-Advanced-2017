package reflection.mirrorimage.enums;

public enum SpellType {
    FIREBALL,
    REFLECTION
}
