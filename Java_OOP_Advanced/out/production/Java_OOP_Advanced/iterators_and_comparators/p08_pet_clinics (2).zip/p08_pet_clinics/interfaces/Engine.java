package iterators_and_comparators.p08_pet_clinics.interfaces;

import java.io.IOException;

public interface Engine {
    void run() throws IOException;
}
