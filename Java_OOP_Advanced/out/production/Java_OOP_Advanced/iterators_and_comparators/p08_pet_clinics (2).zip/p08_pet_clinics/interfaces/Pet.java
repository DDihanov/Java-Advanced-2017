package iterators_and_comparators.p08_pet_clinics.interfaces;

public interface Pet {
    String getName();
    int getAge();
    String getKind();
}
