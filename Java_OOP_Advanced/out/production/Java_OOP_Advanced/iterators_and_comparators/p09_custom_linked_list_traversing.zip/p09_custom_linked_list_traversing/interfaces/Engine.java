package iterators_and_comparators.p09_custom_linked_list_traversing.interfaces;

import java.io.IOException;

public interface Engine{
    void run() throws IOException;
}
