package iterators_and_comparators.p07_equality_logic.interfaces;

public interface Person {
    String getName();
    int getAge();
}
