package Inheritance.P06_Animals.models;

public class Tomcat extends Cat {
    public Tomcat(String name, int age, String gender) {
        super(name, age, gender);
    }


    @Override
    protected void setGender(String gender) {
        if(!gender.toLowerCase().equals("male")){
            throw new IllegalArgumentException("Invalid input!");
        }
        super.setGender(gender);
    }

    @Override
    public String produceSound() {
        return "Give me one million b***h";
    }
}
