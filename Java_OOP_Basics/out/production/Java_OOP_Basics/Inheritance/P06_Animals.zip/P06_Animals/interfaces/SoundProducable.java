package Inheritance.P06_Animals.interfaces;

public interface SoundProducable {
    String produceSound();
}
